﻿using EMS_MiniProject.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EMS_MiniProject.Controllers
{
    [ApiController]
    [Route("api/employee")]
    [Authorize(Roles = "Employee")]
    public class EmployeeDashboardController : Controller
    {
        private readonly IUserRepository _userRepository;

        public EmployeeDashboardController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard()
        {
            var username = User.Identity.Name;

            var user = await _userRepository.GetUserAsync(username);

            return Ok(new
            {
                UserId = user.Id,
                Username = user.Username,
                Role = user.Role.RoleName
            });
        }
    }
}
