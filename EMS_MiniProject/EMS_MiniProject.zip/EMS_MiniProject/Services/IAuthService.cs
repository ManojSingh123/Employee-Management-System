﻿using EMS_MiniProject.DTOs;

namespace EMS_MiniProject.Services
{
    public interface IAuthService
    {
        Task<LoginResponseDto> AuthenticateAsync(LoginRequestDto request);
        string HashPassword(string password);
        bool VerifyPassword(string password, string passwordHash);
    }
}
