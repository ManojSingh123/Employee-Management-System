﻿using EMS_MiniProject.DTOs;
using EMS_MiniProject.Helper;
using EMS_MiniProject.Repositories;
using System.IdentityModel.Tokens.Jwt;

namespace EMS_MiniProject.Services
{
    public class AuthService:IAuthService
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _config;

        public AuthService(IUserRepository userRepository, IConfiguration config)
        {
            _userRepository = userRepository;
            _config = config;
        }

        public string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        public bool VerifyPassword(string password, string passwordHash)
        {
            return BCrypt.Net.BCrypt.Verify(password, passwordHash);
        }

        public async Task<LoginResponseDto> AuthenticateAsync(LoginRequestDto request)
        {
            var user = await _userRepository.GetUserAsync(request.Username);

            if (user == null)
                throw new UnauthorizedAccessException("Invalid username or password");

            bool isValid = BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash);

            if (!isValid)
                throw new UnauthorizedAccessException("Invalid username or password");

            var token = JwtHelper.GenerateJwtToken(user, _config["Jwt:Key"], _config["Jwt:Issuer"], _config["Jwt:ExpireMinutes"]);

            return new LoginResponseDto
            {
                Token = token,
                Role = user.Role.RoleName
            };
        }
    }
}
