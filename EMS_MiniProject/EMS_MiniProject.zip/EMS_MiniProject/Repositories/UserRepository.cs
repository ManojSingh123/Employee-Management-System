﻿using EMS_MiniProject.DataContext;
using EMS_MiniProject.Models;
using Microsoft.EntityFrameworkCore;

namespace EMS_MiniProject.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;   
        public UserRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<User?> GetUserAsync(string username)
        {
            return await _context.Users
                                 .FirstOrDefaultAsync(u => u.Username == username);   
        }
        public async Task AddUserAsync(User user)
        {
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
        }

        public async Task<List<User>> GetAllEmployeesAsync()
        {
            return await _context.Users
                .Include(u => u.Role)
                .Where(u => u.Role.RoleName == "Employee")
                .ToListAsync();
        }
    }
}
